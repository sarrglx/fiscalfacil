# FiscalFácil

Primera versión funcional de una app web responsive en español. Usa exclusivamente datos ficticios. No conecta con el SAT, no presenta declaraciones, no calcula impuestos ni comparte información con otras personas.

## Ejecutar localmente

Necesitas Node.js 20 o superior y npm (incluido en la instalación habitual de Node.js).

1. Abre una terminal en esta carpeta.
2. Ejecuta `npm install` una sola vez para instalar la biblioteca de importación Excel/CSV.
3. Ejecuta `npm start`.
4. Abre http://localhost:4173 en el navegador.

Si recibes la carpeta con `node_modules` ya preparado, puedes ejecutar directamente `node server.mjs`. También se admite `pnpm install` y `pnpm start`; se incluye su archivo de versiones.

Acceso ficticio: **santiago.demo** / **demo1234**. La pantalla los muestra para facilitar las pruebas. No uses datos reales. Cerrar sesión conserva los movimientos de práctica.

## Qué puedes probar

- Login demo, sin autenticación real; sesión en sessionStorage.
- Dashboard con resumen, tarjetas y semáforo explicado en Revisión.
- Movimientos y facturas simuladas, con búsqueda por concepto o folio.
- CSV, XLSX y XLS: selección de archivo, validación, vista previa y confirmación antes de agregar filas. La primera hoja se procesa localmente. Incluye un CSV de ejemplo y un botón para descargar un XLSX de ejemplo.
- Calendario navegable entre meses, actividades completables y recordatorios visibles solo dentro de la app.
- Guía de cuatro pasos con progreso persistente.
- Asistente de respuestas predefinidas que consulta los totales actuales.
- Modo accesible: texto y controles grandes, menos elementos secundarios, navegación directa, enfoque visible y diseño de una columna.
- Avisos por folio vacío o repetido. Revisarlos cambia el semáforo, sin modificar el dato original.
- Perfiles ficticios de familiar/contador, selección y visualización del alcance de permisos y revocación. No existe una cuenta invitada ni control de acceso real.

El calendario usa **7 de septiembre de 2026** como fecha fija de referencia. Todas las actividades y fechas son inventadas. El resumen suma todos los registros, independientemente de su mes. Las filas importadas se agregan a las existentes; un folio repetido genera un aviso, no una eliminación automática.

## Formato de importación

Columnas obligatorias: `fecha,concepto,tipo,monto,folio`.

- `fecha`: texto AAAA-MM-DD, también en Excel. Ejemplo: `2026-09-02`.
- `concepto`: texto de 1 a 200 caracteres.
- `tipo`: `ingreso` o `gasto`.
- `monto`: número positivo con punto decimal, sin símbolos monetarios ni separadores de miles.
- `folio`: puede quedar vacío; se generará un aviso. No se valida CFDI.

Máximo 2 MB y 5,000 filas por archivo. Si una fila no es válida, se rechaza todo el archivo y se indica el motivo. Vista previa de 20 filas y resumen de todas. Los CSV deben usar codificación UTF-8. No importes archivos no confiables: esta versión usa SheetJS CE 0.18.5 del registro npm para la demo, cuya sustitución por una versión mantenida debe revisarse antes de producción.

## Estructura para hacer cambios

- `index.html`: entrada de la aplicación.
- `styles.css`: colores, componentes, móvil y modo accesible.
- `src/app.js`: pantallas, navegación y acciones.
- `src/domain.js`: datos iniciales, reglas de revisión, importación y respuestas simuladas.
- `server.mjs`: servidor local ligado solo a 127.0.0.1.
- `tests/domain.test.mjs`: pruebas de sumas, avisos, semáforo y validación.
- `ejemplo.csv`: archivo ficticio para probar.

No requiere compilación. Modifica un archivo y recarga el navegador. Ejecuta `npm test` o `node --test tests/*.test.mjs` para las pruebas.

## Guardado y límites

Los cambios se guardan en `localStorage`, clave `fiscalfacil-v1`. Borrar los datos del sitio en el navegador restablece la demo. No hay servidor de datos, cifrado, sincronización, autenticación, notificaciones fuera de la app, IA real ni permisos efectivos. La sesión demo es deliberadamente accesible y no protege información. El chat no se conserva al recargar.

Para una versión real harán falta un backend con autenticación y autorización verificadas, almacenamiento seguro, gestión de consentimiento, reglas fiscales revisadas y una integración oficial. Este proyecto sirve como base de producto y de interfaz, no como sistema fiscal de producción.

## Novedades de esta versión

El primer acceso abre un cuestionario de tres pasos: escenario, experiencia y prioridad. Puedes omitirlo, volver atrás o cambiar tus respuestas desde **Mi punto de partida**. Las preferencias se conservan en este navegador y generan una ruta educativa; no determinan un régimen fiscal. Los movimientos demo se conservan al actualizar.

**XML ficticios:** descarga ejemplo.xml desde Importar archivos. Usa un formato propio FiscalFacilDemo (version=1 y ficticio=true) con elementos Movimiento y los mismos cinco campos del CSV como atributos. Se validan los datos antes de mostrar una vista previa y solo se agregan al confirmar. Importar dos veces puede generar avisos de folio duplicado. Los archivos oficiales CFDI, XML mal formado y declaraciones de entidades se rechazan. No valida sellos, impuestos ni autenticidad; no descarga documentos del SAT.

Nuevos módulos: src/welcome.js define preguntas y rutas; src/xml.js lee y valida el formato XML ficticio. La cámara y OCR quedan para una siguiente etapa.
