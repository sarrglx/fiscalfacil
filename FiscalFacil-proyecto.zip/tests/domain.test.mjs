import test from 'node:test';
import assert from 'node:assert/strict';
import {seed,totals,issues,normalizeRows,fiscalStatus,answer} from '../src/domain.js';
test('el resumen suma ingresos y gastos sin calcular impuestos',()=>assert.deepEqual(totals(seed().rows),{ingreso:38000,gasto:6000}));
test('detecta folios vacíos y duplicados sin distinguir mayúsculas',()=>{const r=seed().rows;r.push({...r[0],folio:'demo-001'});assert.equal(issues(r).length,2);});
test('revisar todos los avisos cambia el semáforo',()=>{const s=seed();assert.equal(fiscalStatus(s).tone,'amber');s.resolved=issues(s.rows).map(x=>x.id);assert.equal(fiscalStatus(s).tone,'green');});
test('rechaza importaciones con esquema, fecha o montos incorrectos',()=>{const valid={fecha:'2026-09-01',concepto:'Demo',tipo:'ingreso',monto:'100.50',folio:''};assert.equal(normalizeRows([valid])[0].monto,100.5);for(const patch of [{fecha:'2026-02-30'},{monto:''},{monto:'-1'},{monto:'1,000'},{tipo:'otro'},{concepto:''}])assert.throws(()=>normalizeRows([{...valid,...patch}]));assert.throws(()=>normalizeRows([{fecha:'2026-09-01'}]));assert.throws(()=>normalizeRows([]));assert.throws(()=>normalizeRows(Array(5001).fill(valid)));});
test('el asistente usa los movimientos actuales y aclara su simulación',()=>{assert.match(answer('ingresos',seed()),/38,000/);assert.match(answer('hola',seed()),/simulado/);});
